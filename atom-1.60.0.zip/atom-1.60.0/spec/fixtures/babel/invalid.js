'use 6to6';

export default 42;
