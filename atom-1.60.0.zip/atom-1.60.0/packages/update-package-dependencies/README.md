## Update Package Dependencies package

Runs `apm install` from the current project's directory. This will install all dependencies referenced in the `package.json` file to the `node_modules` folder.

This should only be used in projects that are Atom packages.
